<?php

namespace plugins\messagesOnLike;

use app\forms\MessageForm;
use Yii;
use yii\base\Event;
use yii\base\BootstrapInterface;
use yii\base\ModelEvent;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\messagesOnLike
 */
class Plugin extends \app\plugins\Plugin implements BootstrapInterface
{
    /**
     * @param \yii\base\Application $app
     */
    public function bootstrap($app)
    {
        if ($app instanceof \yii\web\Application) {
            Event::on(MessageForm::class, MessageForm::EVENT_BEFORE_VALIDATE, [$this, 'onBeforeMessageValidate']);
        }
    }

    /**
     * @param ModelEvent $event
     * @return bool
     * @throws \Exception
     */
    public function onBeforeMessageValidate($event)
    {
        /** @var MessageForm $messageForm */
        $messageForm = $event->sender;

        $sender = Yii::$app->user->identity;
        $receiver = Yii::$app->userManager->getUserById($messageForm->contactId);

        if ($sender == null || $receiver == null) {
            return false;
        }

        if (!Yii::$app->likeManager->isMutualLike($sender, $receiver)) {
            $messageForm->addError('message', Yii::t('youdate', 'Only users who like each other can send messages to each other'));
            $event->isValid = false;
            return false;
        }

        return true;
    }
}
