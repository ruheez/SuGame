<?php

namespace plugins\fakes\forms;

use app\base\Model;
use app\models\Profile;
use Yii;
use yii\web\UploadedFile;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\fakes\forms
 */
class FakesConfig extends Model
{
    const SEX_RANDOM = 0;

    const VERIFIED_RANDOM = -1;
    const VERIFIED_NO = 0;
    const VERIFIED_YES = 1;

    /**
     * @var integer
     */
    public $amount;
    /**
     * @var integer
     */
    public $sex;
    /**
     * @var integer
     */
    public $fromAge = 18;
    /**
     * @var integer
     */
    public $toAge = 40;
    /**
     * @var string
     */
    public $country;
    /**
     * @var integer
     */
    public $city;
    /**
     * @var string
     */
    public $locale;
    /**
     * @var integer
     */
    public $verified;
    /**
     * @var string
     */
    public $password;
    /**
     * @var UploadedFile
     */
    public $photosArchive;

    /**
     * @return array
     */
    public function rules()
    {
        return [
            [['amount'], 'required'],
            [['amount'], 'integer', 'min' => 1, 'max' => 5000],
            [['sex'], 'integer'],
            [['sex'], 'in', 'range' => array_keys($this->getSexOptions())],
            [['locale'], 'default', 'value' => 'en_US'],
            [['locale'], 'in', 'range' => array_keys($this->getLocaleOptions())],
            [['verified'], 'in', 'range' => array_keys($this->getVerifiedOptions())],
            [['password'], 'string', 'min' => 4, 'max' => 32],
            [['locale'], 'default', 'value' => 'fakefake'],
            [['fromAge', 'toAge'], 'integer', 'min' => 18, 'max' => 100],
            ['fromAge', 'compare', 'compareAttribute' => 'toAge', 'operator' => '<=', 'when' => function (FakesConfig $config) {
                return !empty($config->fromAge) && !empty($config->toAge);
            }],
            ['country', 'string', 'min' => 2, 'max' => 2],
            ['country', function ($attribute, $params) {
                return Yii::$app->geographer->isValidCountryCode($this->$attribute);
            }],
            ['city', 'integer', 'min' => 0],
            ['city', function ($attribute, $params) {
                return Yii::$app->geographer->isValidCityCode($this->$attribute);
            }],
            ['photosArchive', 'file', 'extensions' => 'zip'],
        ];
    }

    /**
     * @return array
     */
    public function attributeLabels()
    {
        return [
            'amount' => Yii::t('app', 'Amount'),
            'sex' => Yii::t('app', 'Sex/Gender'),
            'locale' => Yii::t('app', 'Locale'),
            'fromAge' => Yii::t('app', 'From Age'),
            'toAge' => Yii::t('app', 'To Age'),
            'country' => Yii::t('app', 'Country'),
            'city' => Yii::t('app', 'City'),
            'password' => Yii::t('app', 'Password'),
            'verified' => Yii::t('app', 'Verified'),
        ];
    }

    /**
     * @return array
     */
    public function getSexOptions()
    {
        return (new Profile())->getSexOptions(true);
    }

    /**
     * @return array
     */
    public function getVerifiedOptions()
    {
        return [
            self::VERIFIED_RANDOM => Yii::t('app', 'Random'),
            self::VERIFIED_YES => Yii::t('app', 'Yes'),
            self::VERIFIED_NO => Yii::t('app', 'No'),
        ];
    }

    /**
     * @return array
     */
    public function getLocaleOptions()
    {
        return [
            'ar_JO' => 'Arabic (Jordan)',
            'ar_SA' => 'Arabic (Saudi Arabia)',
            'bg_BG' => 'Bulgarian (Bulgaria)',
            'bn_BD' => 'Bengali (Bangladesh)',
            'cs_CZ' => 'Czech (Czech Republic)',
            'da_DK' => 'Danish (Denmark)',
            'de_AT' => 'German (Austria)',
            'de_CH' => 'German (Switzerland)',
            'de_DE' => 'German (Germany)',
            'el_CY' => 'Greek (Cyprus)',
            'el_GR' => 'Greek (Greece)',
            'en_AU' => 'English (Australia)',
            'en_CA' => 'English (Canada)',
            'en_GB' => 'English (United Kingdom)',
            'en_US' => 'English (United States)',
            'en_HK' => 'English (Hong Kong SAR China)',
            'en_IN' => 'English (India)',
            'en_NZ' => 'English (New Zealand)',
            'en_NG' => 'English (Nigeria)',
            'en_PH' => 'English (Philippines)',
            'en_SG' => 'English (Singapore)',
            'en_ZA' => 'English (South Africa)',
            'es_AR' => 'Spanish (Argentina)',
            'es_ES' => 'Spanish (Spain)',
            'es_PE' => 'Spanish (Peru)',
            'es_VE' => 'Spanish (Venezuela)',
            'fa_IR' => 'Persian (Iran)',
            'fi_FI' => 'Finnish (Finland)',
            'fr_BE' => 'French (Belgium)',
            'fr_CA' => 'French (Canada)',
            'fr_CH' => 'French (Switzerland)',
            'fr_FR' => 'French (France)',
            'he_IL' => 'Hebrew (Israel)',
            'hr_HR' => 'Croatian (Croatia)',
            'hy_AM' => 'Armenian (Armenia)',
            'hu_HU' => 'Hungarian (Hungary)',
            'id_ID' => 'Indonesian (Indonesia)',
            'is_IS' => 'Icelandic (Iceland)',
            'it_IT' => 'Italian (Italy)',
            'it_CH' => 'Italian (Switzerland)',
            'ja_JP' => 'Japanese (Japan)',
            'ka_GE' => 'Georgian (Georgia)',
            'kk_KZ' => 'Kazakh (Kazakhstan)',
            'ko_KR' => 'Korean (South Korea)',
            'lt_LT' => 'Lithuanian (Lithuania)',
            'lv_LV' => 'Latvian (Latvia)',
            'mn_MN' => 'Mongolian (Mongolia)',
            'ms_MY' => 'Malay (Malaysia)',
            'nb_NO' => 'Norwegian Bokmål (Norway)',
            'ne_NP' => 'Nepali (Nepal)',
            'nl_BE' => 'Dutch (Belgium)',
            'nl_NL' => 'Dutch (Netherlands)',
            'pl_PL' => 'Polish (Poland)',
            'pt_BR' => 'Portuguese (Brazil)',
            'pt_PT' => 'Portuguese (Portugal)',
            'ro_RO' => 'Romanian (Romania)',
            'ru_RU' => 'Russian (Russia)',
            'sk_SK' => 'Slovak (Slovakia)',
            'sl_SI' => 'Slovenian (Slovenia)',
            'sr_RS' => 'Serbian (Serbia)',
            'sv_SE' => 'Swedish (Sweden)',
            'th_TH' => 'Thai (Thailand)',
            'tr_TR' => 'Turkish (Turkey)',
            'uk_UA' => 'Ukrainian (Ukraine)',
            'vi_VN' => 'Vietnamese (Vietnam)',
            'zh_TW' => 'Chinese (Taiwan)',
            'zh_CN' => 'Chinese (China)',
        ];
    }
}
