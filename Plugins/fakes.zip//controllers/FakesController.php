<?php

namespace plugins\fakes\controllers;

use plugins\fakes\components\Controller;
use plugins\fakes\components\Generator;
use plugins\fakes\forms\FakesConfig;
use Yii;
use yii\web\UploadedFile;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\fakes\controllers
 */
class FakesController extends Controller
{
    /**
     * @return string|\yii\web\Response
     * @throws \League\Flysystem\FileExistsException
     * @throws \yii\base\ErrorException
     * @throws \yii\base\Exception
     * @throws \yii\db\Exception
     */
    public function actionGenerate()
    {
        $fakesConfig = new FakesConfig();

        if ($fakesConfig->load(Yii::$app->request->post())) {
            $fakesConfig->photosArchive = UploadedFile::getInstance($fakesConfig, 'photosArchive');
            $fakesGenerator = new Generator();
            $fakesGenerator->setFakeConfig($fakesConfig);
            if ($fakesConfig->validate()) {
                $createdUsersCount = $fakesGenerator->generate();
                if ($createdUsersCount > 0) {
                    Yii::$app->session->setFlash('success',
                        Yii::t('app', 'Created {0} fake users', $createdUsersCount)
                    );
                    return $this->refresh();
                }
            }
        }

        return $this->render('generate', [
            'fakesConfig' => $fakesConfig,
            'countries' => Yii::$app->geographer->getCountriesList(),
        ]);
    }
}
