<?php

namespace plugins\fakes;

use app\base\Event;
use app\modules\admin\Module;
use app\modules\admin\widgets\Menu;
use plugins\fakes\controllers\FakesController;
use Yii;
use yii\base\BootstrapInterface;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\demo
 */
class Plugin extends \app\plugins\Plugin implements BootstrapInterface
{
    /**
     * @param \yii\base\Application $app
     * @return bool
     */
    public function bootstrap($app)
    {
        Yii::setAlias('@plugins/fakes', dirname(__FILE__));

        if (Yii::$app instanceof \yii\web\Application) {
            $this->setupWebApp($app);
        }

        return true;
    }

    /**
     * @param $app
     * @return bool
     */
    public function setupWebApp($app)
    {
        if (Yii::$app->user->isGuest || !Yii::$app->user->identity->isAdmin) {
            return false;
        }

        Event::on(Menu::class, Menu::EVENT_INIT, [$this, 'onAdminEventInit']);
        Event::on(Module::class, Module::EVENT_BEFORE_INIT, [$this, 'onAdminModuleInit']);

        return true;
    }

    /**
     * @param \yii\base\Event $event
     */
    public function onAdminEventInit($event)
    {
        /** @var Menu $widget */
        $widget = $event->sender;
        $widget->items[] = [
            'label' => Yii::t('app', 'Fakes generator'),
            'icon' => 'fa fa-user-plus',
            'url' => ['fakes/generate'],
            'order' => 111,
        ];
    }

    /**
     * @param \yii\base\Event $event
     */
    public function onAdminModuleInit($event)
    {
        /** @var Module $module */
        $module = $event->sender;
        $module->controllerMap['fakes'] = FakesController::class;
    }
}
