<?php

namespace plugins\fakes\components;

use Yii;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\fakes\components
 */
class Controller extends \app\modules\admin\components\Controller
{
    /**
     * @return bool|string
     */
    public function getViewPath()
    {
        return Yii::getAlias('@plugins/fakes/views/' . $this->id);
    }
}
