<?php

namespace plugins\fakes\components;

use app\helpers\Password;
use app\models\Photo;
use app\models\Profile;
use app\models\User;
use MenaraSolutions\Geographer\City;
use plugins\fakes\forms\FakesConfig;
use Symfony\Component\Finder\Finder;
use Yii;
use yii\base\Component;
use yii\db\Command;
use yii\helpers\ArrayHelper;
use yii\helpers\FileHelper;
use yii\validators\FileValidator;
use yii\web\UploadedFile;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\fakes\components
 */
class Generator extends Component
{
    /**
     * @var FakesConfig
     */
    private $fakeConfig;
    /**
     * @var \Faker\Generator
     */
    private $faker;
    /**
     * @var array
     */
    private $photos;
    /**
     * @var Command
     */
    private $cmd;
    /**
     * @var string
     */
    private $passwordHash;

    /**
     * @param FakesConfig $config
     */
    public function setFakeConfig(FakesConfig $config)
    {
        $this->fakeConfig = $config;
    }

    /**
     * @return int
     * @throws \yii\base\Exception
     * @throws \yii\db\Exception
     * @throws \yii\base\ErrorException
     * @throws \League\Flysystem\FileExistsException
     */
    public function generate()
    {
        $createdUsersCount = 0;
        $this->faker = \Faker\Factory::create($this->fakeConfig->locale);
        $this->cmd = Yii::$app->db->createCommand();
        $this->preparePhotos();

        for ($i = 0; $i < $this->fakeConfig->amount; $i++) {
            if ($this->create()) {
                $createdUsersCount++;
            }
        }

        return $createdUsersCount;
    }

    /**
     * @return bool
     * @throws \yii\base\Exception
     * @throws \yii\db\Exception
     */
    private function create()
    {
        $userId = $this->createUser();
        if (!$userId) {
            return false;
        }

        $this->createProfile($userId);
        $this->attachPhotos($userId);

        return true;
    }

    /**
     * @return int
     * @throws \yii\base\Exception
     * @throws \yii\db\Exception
     */
    private function createUser()
    {
        $attributes = [
            'username' => $this->faker->userName . '_' . $this->faker->numberBetween(1, 30000),
            'email' => $this->faker->numberBetween(1000, 300) . $this->faker->email,
            'password_hash' => $this->getPasswordHash($this->fakeConfig->password),
            'auth_key' => Yii::$app->security->generateRandomString(),
            'confirmed_at' => time(),
            'created_at' => time(),
            'updated_at' => time(),
            'last_login_at' => time(),
            'flags' => 0,
        ];

        if (version_compare(version(), '2.0.0', '>=')) {
            $attributes['tag'] = 'fake';
        }

        $this->cmd->insert(User::tableName(), $attributes)->execute();

        return Yii::$app->db->getLastInsertID();
    }

    /**
     * @param $userId
     * @return Profile|null
     * @throws \yii\base\InvalidConfigException
     * @throws \yii\db\Exception
     */
    private function createProfile($userId)
    {
        $profileModel = new Profile();
        $sexOptions = array_keys($profileModel->getSexOptions());
        $sex = empty($this->fakeConfig->sex) ? $this->faker->randomElement($sexOptions) : $this->fakeConfig->sex;

        $city = null;
        try {
            $city = City::build($this->fakeConfig->city);
        } catch (\Exception $e) {
            // city not found
        }

        $dobFrom = $this->fakeConfig->fromAge ?? 18;
        $dobTo = $this->fakeConfig->toAge ?? 40;
        $lookingFromAge = $this->faker->numberBetween(18, 40);
        $this->cmd->insert(Profile::tableName(), [
            'user_id' => $userId,
            'name' => sprintf('%s %s',
                $this->faker->firstName($sex == Profile::SEX_MALE ? 'male' : 'female'),
                $this->faker->lastName($sex == Profile::SEX_MALE ? 'male' : 'female')
            ),
            'dob' => $this->faker->dateTimeBetween("-$dobTo years", "-$dobFrom years")->format('Y-m-d'),
            'looking_for_from_age' => $lookingFromAge,
            'looking_for_to_age' => $lookingFromAge + $this->faker->numberBetween(0, 20),
            'looking_for_sex' => $this->faker->randomElement($sexOptions),
            'status' => $this->faker->randomElement(array_keys($profileModel->getStatusOptions())),
            'sex' => $sex,
            'country' => $this->fakeConfig->country,
            'city' => $city !== null ? $this->fakeConfig->city : null,
            'latitude' => $city !== null ? $city->getLatitude() : null,
            'longitude' => $city !== null ? $city->getLongitude() : null,
            'is_verified' => $this->fakeConfig->verified == FakesConfig::VERIFIED_RANDOM ? mt_rand(0, 1) : $this->fakeConfig->verified,
        ])->execute();

        return Profile::findOne(['user_id' => Yii::$app->db->getLastInsertID()]);
    }

    /**
     * @param $userId
     * @return bool
     * @throws \yii\db\Exception
     */
    private function attachPhotos($userId)
    {
        if (!is_array($this->photos) || count($this->photos) == 0) {
            return false;
        }

        $photoKey = array_rand($this->photos);
        try {
            $this->cmd->insert(Photo::tableName(), [
                'user_id' => $userId,
                'is_verified' => 1,
                'source' => ArrayHelper::remove($this->photos, $photoKey),
            ])->execute();

        } catch (\Exception $exception) {
            dd($this->photos);
        }

        $photoId = Yii::$app->db->getLastInsertID();
        $this->cmd->update(Profile::tableName(), ['photo_id' => $photoId], ['user_id' => $userId])->execute();

        return true;
    }

    /**
     * @param $password
     * @return mixed|string
     * @throws \yii\base\Exception
     */
    private function getPasswordHash($password)
    {
        if (isset($this->passwordHash)) {
            return $this->passwordHash;
        }

        $this->passwordHash = Password::hash($password);

        return $this->passwordHash;
    }

    /**
     * @return bool
     * @throws \yii\base\ErrorException
     * @throws \yii\base\Exception
     * @throws \yii\base\InvalidConfigException
     * @throws \League\Flysystem\FileExistsException
     */
    private function preparePhotos()
    {
        if (!$this->fakeConfig->photosArchive instanceof UploadedFile) {
            return false;
        }

        $zip = new \ZipArchive();
        if ($zip->open($this->fakeConfig->photosArchive->tempName) !== true) {
            return false;
        }

        $tempDirectory = Yii::getAlias('@runtime') . '/fakes-generator-' . time();
        FileHelper::createDirectory($tempDirectory);
        $zip->extractTo(Yii::getAlias($tempDirectory));
        $zip->close();

        $finder = new Finder();
        $photoFinder = $finder->files()->name('*.jpg')->name('*.jpeg');

        foreach ($photoFinder->in($tempDirectory) as $photo) {
            /** @var $photo \SplFileInfo */
            $mimeType = FileHelper::getMimeType($photo->getRealPath(), null, true);
            if ($mimeType == 'image/jpeg') {
                $this->photos[] = Yii::$app->photoStorage->save($photo->getRealPath());
            }
        }

        FileHelper::removeDirectory($tempDirectory);
        return true;
    }
}
