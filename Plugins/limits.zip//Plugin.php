<?php

namespace plugins\limits;

use app\base\Event;
use app\forms\MessageForm;
use app\helpers\Html;
use app\models\Message;
use app\settings\HasSettings;
use Yii;
use yii\base\BootstrapInterface;
use yii\base\ModelEvent;
use yii\console\Application as ConsoleApplication;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\limits
 */
class Plugin extends \app\plugins\Plugin implements BootstrapInterface, HasSettings
{
    const SETTINGS_MESSAGES_ONLY_PREMIUM = 'messagesOnlyPremium';
    const SETTINGS_MESSAGES_FREE_PER_CHAT = 'messagesFreePlanPerChat';
    const SETTINGS_MESSAGES_FREE_PER_DAY = 'messagesFreePlanPerDay';
    const SETTINGS_MESSAGES_PREMIUM_PER_CHAT = 'messagesPremiumPerChat';
    const SETTINGS_MESSAGES_PREMIUM_PER_DAY = 'messagesPremiumPerDay';

    /**
     * @param \yii\base\Application $app
     */
    public function bootstrap($app)
    {
        if ($app instanceof ConsoleApplication) {
            return;
        }

        if (Yii::$app->user->isGuest || Yii::$app->user->identity->isAdmin) {
            return;
        }

        $this->setupMessages();
    }

    private function setupMessages()
    {
        Event::on(MessageForm::class, Message::EVENT_BEFORE_VALIDATE, function (ModelEvent $event) {

            /** @var MessageForm $messageForm */
            $messageForm = $event->sender;

            if (Yii::$app->balanceManager->isPremiumFeaturesEnabled() && Yii::$app->user->identity->isPremium) {
                $isPremium = true;
                $perChat = $this->getSetting(self::SETTINGS_MESSAGES_PREMIUM_PER_CHAT);
                $perDay = $this->getSetting(self::SETTINGS_MESSAGES_PREMIUM_PER_DAY);
            } else {
                $isPremium = false;
                $perChat = $this->getSetting(self::SETTINGS_MESSAGES_FREE_PER_CHAT);
                $perDay = $this->getSetting(self::SETTINGS_MESSAGES_FREE_PER_DAY);
            }
            $onlyPremiumAllowed = $this->getSetting(self::SETTINGS_MESSAGES_ONLY_PREMIUM);

            if ($onlyPremiumAllowed && !$isPremium) {
                $messageForm->addError('message',
                    Yii::t('app', 'You need premium status to send private messages. {upgradeLink}', [
                        'upgradeLink' => Html::a(Yii::t('app', 'Upgrade to premium'), ['/balance/services'])
                    ])
                );
                $event->isValid = false;
                return;
            }

            if ($perDay > 0) {
                $messagesCountDay = Message::find()
                    ->where(['from_user_id' => Yii::$app->user->id])
                    ->andWhere('created_at > UNIX_TIMESTAMP(NOW() - INTERVAL 24 HOUR)')
                    ->count();
                if ($messagesCountDay >= $perDay) {
                    $messageForm->addError('message', $isPremium ?
                        Yii::t('app', 'You have reached daily messages limit') :
                        Yii::t('app', 'You have reached daily messages limit. {upgradeLink}', [
                            'upgradeLink' => Html::a(Yii::t('app', 'Upgrade to premium'), ['/balance/services'])
                        ])
                    );
                    $event->isValid = false;
                }
            }
            if ($perChat > 0) {
                $messagesCountChat = Message::find()
                    ->where(['from_user_id' => Yii::$app->user->id, 'to_user_id' => $messageForm->contactId])
                    ->andWhere('created_at > UNIX_TIMESTAMP(NOW() - INTERVAL 24 HOUR)')
                    ->count();
                if ($messagesCountChat >= $perChat) {
                    $messageForm->addError('message', $isPremium ?
                        Yii::t('app', 'You have reached daily messages limit for this conversation') :
                        Yii::t('app', 'You have reached daily messages limit for this conversation. {upgradeLink}', [
                            'upgradeLink' => Html::a(Yii::t('app', 'Upgrade to premium'), ['/balance/services'])
                        ])
                    );
                    $event->isValid = false;
                }
            }
        });
    }

    /**
     * @return array
     */
    public function getSettings()
    {
        return [
            [
                'alias' => self::SETTINGS_MESSAGES_ONLY_PREMIUM,
                'type' => 'checkbox',
                'label' => Yii::t('app', 'Only premium users are allowed to send messages'),
                'rules' => [
                    ['default', 'value' => false],
                    ['boolean'],
                ]
            ],
            [
                'alias' => self::SETTINGS_MESSAGES_FREE_PER_CHAT,
                'type' => 'number',
                'label' => Yii::t('app', 'Maximum messages per chat (free plan)'),
                'help' => Yii::t('app', 'Set 0 for unlimited messages'),
                'rules' => [
                    ['default', 'value' => 10],
                    ['integer', 'min' => 0, 'max' => 10000],
                ]
            ],
            [
                'alias' => self::SETTINGS_MESSAGES_FREE_PER_DAY,
                'type' => 'number',
                'label' => Yii::t('app', 'Maximum messages per day (free plan)'),
                'help' => Yii::t('app', 'Set 0 for unlimited messages'),
                'rules' => [
                    ['default', 'value' => 25],
                    ['integer', 'min' => 0, 'max' => 10000],
                ]
            ],
            [
                'alias' => self::SETTINGS_MESSAGES_PREMIUM_PER_CHAT,
                'type' => 'number',
                'label' => Yii::t('app', 'Maximum messages per chat (premium plan)'),
                'help' => Yii::t('app', 'Set 0 for unlimited messages'),
                'rules' => [
                    ['default', 'value' => 10],
                    ['integer', 'min' => 0, 'max' => 10000],
                ]
            ],
            [
                'alias' => self::SETTINGS_MESSAGES_PREMIUM_PER_DAY,
                'type' => 'number',
                'label' => Yii::t('app', 'Maximum messages per day (premium plan)'),
                'help' => Yii::t('app', 'Set 0 for unlimited messages'),
                'rules' => [
                    ['default', 'value' => 25],
                    ['integer', 'min' => 0, 'max' => 10000],
                ]
            ],
        ];
    }
}
