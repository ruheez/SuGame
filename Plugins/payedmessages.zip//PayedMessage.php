<?php

namespace plugins\payedmessages;

use app\controllers\GroupController;
use app\forms\PostForm;
use app\models\Post;
use yii\base\Widget;
use plugins\payedmessages\payments\MessageTransaction;
use app\base\Event;
use app\forms\MessageForm;
use app\helpers\Html;
use app\models\Message;
use app\settings\HasSettings;
use Yii;
use yii\base\BootstrapInterface;
use yii\base\ModelEvent;
use yii\base\WidgetEvent;
use yii\console\Application as ConsoleApplication;
use yii\db\AfterSaveEvent;

/**
 * @author Bahne Claussen <hi@bahneclaussen.de>
 * @package plugins\limits
 */
class PayedMessage extends \app\plugins\Plugin implements BootstrapInterface, HasSettings
{
    const SETTINGS_MESSAGES_COST_PER_MESSAGE = 'messagePrice';
    const SETTINGS_POSTS_COST_PER_POST = 'postPrice';

    /**
     * @param \yii\base\Application $app
     */
    public function bootstrap($app)
    {
        if ($app instanceof ConsoleApplication) {
            return;
        }

        if (Yii::$app->user->isGuest || Yii::$app->user->identity->isAdmin) {
            return;
        }

        $this->setupMessages();
    }

    private function setupMessages()
    {
        Event::on(MessageForm::class, Message::EVENT_BEFORE_VALIDATE, function (ModelEvent $event) {
            /** @var MessageForm $messageForm */
            $messageForm = $event->sender;
            $messagePrice = $this->getSetting(self::SETTINGS_MESSAGES_COST_PER_MESSAGE);
            $userId = Yii::$app->user->id;

            if (!Yii::$app->balanceManager->hasEnoughCredits($userId, $messagePrice)) {
                $messageForm->addError('message',
                    Yii::t('app', 'youre out of credits: {upgradeLink}', [
                        'upgradeLink' => Html::a(Yii::t('app', 'get more credits'), ['/balance/services'])
                    ])
                );
                $event->isValid = false;
            } else if ($messagePrice > 0) {
                Yii::$app->balanceManager->decrease(['user_id' => $userId], $messagePrice, [
                    'class' => MessageTransaction::class,
                    'toUserId' => $messageForm->contactId,
                ]);
            }
        });

        if (class_exists(GroupController::class)) {
            $postPrice =  $this->getSetting(self::SETTINGS_POSTS_COST_PER_POST, 0);

            // Validate
            Event::on(PostForm::class, PostForm::EVENT_BEFORE_VALIDATE, function (ModelEvent $event) use ($postPrice) {
                /** @var PostForm $postForm */
                $postForm = $event->sender;
                $postPrice = $this->getSetting(self::SETTINGS_POSTS_COST_PER_POST, 0);
                if ($postPrice == 0) {
                    return true;
                }

                if (!Yii::$app->balanceManager->hasEnoughCredits($postForm->user->id, $postPrice)) {
                    $postForm->addError('content', Yii::t('app', 'You don\'t have enough credits for this operation'));
                    return false;
                }

                return true;
            });

            // Decrease balance on new post
            Event::on(Post::class, Post::EVENT_AFTER_INSERT, function (AfterSaveEvent $event) use ($postPrice) {
                /** @var Post $post */
                $post = $event->sender;
                Yii::$app->balanceManager->decrease(['user_id' => $post->user_id], $postPrice, [
                    'class' => MessageTransaction::class,
                ]);
            });

            // Add warning
            Event::on('youdate\widgets\NewPost', Widget::EVENT_AFTER_RUN, function (WidgetEvent $event) use ($postPrice) {
                try {
                    $balance = Yii::$app->balanceManager->getUserBalance(Yii::$app->user->id);
                    $dom = new \DOMDocument;
                    @$dom->loadHTML($event->result);
                    $xpath = new \DOMXPath($dom);
                    $cardBody = $xpath->query("//*[contains(@class, 'card-body')]")->item(0);
                    if ($balance < $postPrice) {
                        $alert = $dom->createElement('div', Yii::t('app', 'You don\'t have enough credits ({0}) to post', $postPrice));
                        $alert->setAttribute('class', 'alert alert-warning mb-6');
                    } else {
                        $alert = $dom->createElement('div', Yii::t('app', 'New post cost: {0} credits', $postPrice));
                        $alert->setAttribute('class', 'alert alert-primary mb-6');
                    }
                    $cardBody->insertBefore($alert, $cardBody->firstChild);
                    $event->result = $dom->saveHTML();
                } catch (\Exception $exception) {
                    Yii::error($exception->getMessage());
                    if (YII_DEBUG) {
                        throw $exception;
                    }
                }
            });
        }
    }

    /**
     * @return array
     */
    public function getSettings()
    {
        return [
            [
                'alias' => self::SETTINGS_MESSAGES_COST_PER_MESSAGE,
                'type' => 'number',
                'label' => Yii::t('app', 'Message Price'),
                'help' => Yii::t('app', 'Set 0 for free messages'),
                'rules' => [
                    ['default', 'value' => 10],
                    ['integer', 'min' => 0, 'max' => 10000],
                ]
            ],
            [
                'alias' => self::SETTINGS_POSTS_COST_PER_POST,
                'type' => 'number',
                'label' => Yii::t('app', 'Post Price'),
                'help' => Yii::t('app', 'Set 0 for free posts'),
                'rules' => [
                    ['default', 'value' => 10],
                    ['integer', 'min' => 0, 'max' => 10000],
                ]
            ]
        ];
    }
}
