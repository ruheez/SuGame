Extract this Plugin files to `content/plugins/` directory. Now you can install it in admin panel. 

You can edit the amount of a single message in the plugin settings.

PLEASE NOTE:
If you want to translate this code `youre out of credits` and `get more credits` you have to update your translation json file.



For awesome support email me: hi@bahneclaussen.de. For individual request please note that im a freelancer and work for money.