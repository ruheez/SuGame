<?php

namespace plugins\payedmessages\payments;

use app\helpers\Html;
use Yii;

/**
 * @author Bahne Claussen <hi@bahneclaussen.de>
 * @package app\payments
 */
class MessageTransaction extends \app\payments\TransactionInfo
{
    /**
     * @var int
     */
    public $toUserId;

    /**
     * @return string
     */
    public function getType()
    {
        return self::TYPE_PAYMENT;
    }

    /**
     * @return string
     */
    public function getTitle()
    {
        $user = Yii::$app->userManager->getUserById($this->toUserId);
        if ($user !== null) {
            return Yii::t('youdate', 'Message to {0}', Html::a($user->profile->getDisplayName(), ['/profile/view', 'username' => $user->username]));
        } else {
            return Yii::t('youdate', 'Message');
        }
    }

    /**
     * @return string
     */
    public function getServiceName()
    {
        return null;
    }
}
