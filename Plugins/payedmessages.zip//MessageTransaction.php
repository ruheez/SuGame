<?php

namespace plugins\payedmessages;

use app\payments\TransactionInfo;
use Yii;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\payedmessages;
 */
class MessageTransaction extends TransactionInfo
{
    /**
     * @return string
     */
    public function getType()
    {
        return 'default';
    }

    /**
     * @return string
     */
    public function getTitle()
    {
        return Yii::t('app', 'Paid message');
    }

    /**
     * @return string
     */
    public function getServiceName()
    {
        return null;
    }
}
