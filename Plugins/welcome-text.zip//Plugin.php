<?php

namespace plugins\welcomeMessage;

use app\models\User;
use app\settings\HasSettings;
use Yii;
use yii\base\Event;
use yii\base\BootstrapInterface;
use yii\db\AfterSaveEvent;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\welcomeMessage
 */
class Plugin extends \app\plugins\Plugin implements BootstrapInterface, HasSettings
{
    const SETTINGS_FROM_USER = 'welcomeMessageFromUser';
    const SETTINGS_WELCOME_TEXT = 'welcomeMessageText';

    /**
     * @param \yii\base\Application $app
     */
    public function bootstrap($app)
    {
        if ($app instanceof \yii\web\Application) {
            $this->setupWebEvents($app);
        }
    }

    /**
     * @param \yii\web\Application $app
     */
    public function setupWebEvents($app)
    {
        // on user sign up/connect
        Event::on(User::class, User::EVENT_AFTER_INSERT, [$this, 'afterUserCreate']);
    }

    /**
     * @param AfterSaveEvent $event
     * @throws \Exception
     */
    public function afterUserCreate($event)
    {
        /** @var User $user */
        $newUser = $event->sender;
        $fromUser = Yii::$app->userManager->getUser($this->getSetting(self::SETTINGS_FROM_USER));
        $text = $this->getSetting(self::SETTINGS_WELCOME_TEXT);
        if ($fromUser === null || empty($text)) {
            return;
        }

        Yii::$app->messageManager->createMessage($fromUser->id, $newUser->id, $text);
    }

    /**
     * @return array
     */
    public function getSettings()
    {
        return [
            [
                'alias' => self::SETTINGS_FROM_USER,
                'type' => 'text',
                'label' => Yii::t('youdate', 'From User'),
                'rules' => [
                    ['string'],
                ],
                'help' => Yii::t('youdate', 'Username. For example: admin'),
            ],
            [
                'alias' => self::SETTINGS_WELCOME_TEXT,
                'type' => 'text',
                'label' => Yii::t('youdate', 'Welcome text'),
                'rules' => [
                    ['string', 'min' => 1, 'max' => 8000],
                ]
            ],
        ];
    }
}
