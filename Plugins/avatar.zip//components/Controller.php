<?php

namespace plugins\avatar\components;

use Yii;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\avatar\components
 */
class Controller extends \app\modules\admin\components\Controller
{
    /**
     * @return bool|string
     */
    public function getViewPath()
    {
        return Yii::getAlias('@plugins/avatar/views/' . $this->id);
    }
}
