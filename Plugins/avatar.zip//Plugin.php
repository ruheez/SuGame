<?php

namespace plugins\avatar;

use app\events\ProfileEvent;
use app\helpers\Url;
use app\models\Profile;
use app\modules\admin\Module;
use app\modules\admin\widgets\Menu;
use plugins\avatar\controllers\AvatarController;
use Yii;
use yii\base\Event;
use yii\base\BootstrapInterface;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\avatar
 */
class Plugin extends \app\plugins\Plugin implements BootstrapInterface
{
    /**
     * @var string
     */
    public $configFile = '@content/params/avatarParams.json';

    /**
     * @param \yii\base\Application $app
     */
    public function bootstrap($app)
    {
        Yii::setAlias('@plugins/avatar', dirname(__FILE__));

        Event::on(Profile::class, Profile::EVENT_AVATAR_FALLBACK, [$this, 'onAvatarFallback']);

        if (Yii::$app instanceof \yii\web\Application) {
            $this->setupWebApp($app);
        }
    }

    /**
     * @param $app
     * @return bool
     */
    public function setupWebApp($app)
    {
        Event::on(Menu::class, Menu::EVENT_INIT, [$this, 'onAdminEventInit']);
        Event::on(Module::class, Module::EVENT_BEFORE_INIT, [$this, 'onAdminModuleInit']);

        return true;
    }

    /**
     * @param \yii\base\Event $event
     */
    public function onAdminEventInit($event)
    {
        /** @var Menu $widget */
        $widget = $event->sender;
        $widget->items[] = [
            'label' => Yii::t('app', 'Default avatar'),
            'icon' => 'fa fa-image',
            'url' => ['avatar/index'],
            'order' => 221,
            'visible' => Yii::$app->user->identity->isAdmin,
        ];
    }

    /**
     * @param \yii\base\Event $event
     */
    public function onAdminModuleInit($event)
    {
        /** @var Module $module */
        $module = $event->sender;
        $module->controllerMap['avatar'] = AvatarController::class;
    }

    /**
     * @param ProfileEvent $event
     * @return bool|string
     */
    public function onAvatarFallback(ProfileEvent $event)
    {
        $avatar = null;
        $sex = $event->getProfile()->sex;
        $config = $this->loadConfig();

        if (isset($config[$sex])) {
            $event->getProfile()->fallbackAvatar = Url::to($config[$sex], true);
        }

        return true;
    }

    /**
     * @return array
     */
    public function loadConfig()
    {
        $file = Yii::getAlias($this->configFile);
        $sexValues = $this->getSexValues();
        $config = [];
        $data = [];

        if (file_exists($file)) {
            try {
                $data = file_get_contents($file);
                $data = json_decode($data, true);

            } catch (\Exception $exception) {
            }
        }

        foreach ($sexValues as $sex) {
            $config[$sex] = $data[$sex] ?? null;
        }

        return $config;
    }

    /**
     * @param $config
     */
    public function saveConfig($config)
    {
        $file = Yii::getAlias($this->configFile);
        if (is_file($file) && !is_writable($file)) {
            chmod($file, 0775);
        }

        file_put_contents($file, json_encode($config, JSON_PRETTY_PRINT));
    }

    /**
     * @return array
     */
    private function getSexValues()
    {
        $sexOptions = (new Profile())->getSexOptions();
        return array_keys($sexOptions);
    }
}
