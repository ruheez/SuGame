<?php

namespace plugins\avatar\controllers;

use plugins\avatar\forms\AvatarForm;
use plugins\avatar\components\Controller;
use plugins\avatar\Plugin;
use Yii;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\avatar\controllers
 */
class AvatarController extends Controller
{
    public function actionIndex()
    {
        $avatarsForm = AvatarForm::create();
        /** @var Plugin $plugin */
        $plugin = Yii::$app->pluginManager->getInstalledPlugin('avatar');
        $config = $plugin->loadConfig();
        $avatarsForm->config = $config;

        if ($avatarsForm->load(Yii::$app->request->post())) {
            $avatarsForm->getFileInstances();
            if ($avatarsForm->validate()) {
                $avatarsForm->saveFiles();
                $plugin->saveConfig($avatarsForm->config);
                Yii::$app->session->setFlash('success', Yii::t('app', 'Default avatars have been set'));
                return $this->refresh();
            }
        }

        return $this->render('index', [
            'avatarForm' => $avatarsForm,
            'config' => $config,
        ]);
    }
}
