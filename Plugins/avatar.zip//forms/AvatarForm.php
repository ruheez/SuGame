<?php

namespace plugins\avatar\forms;

use app\models\Profile;
use Yii;
use yii\base\DynamicModel;
use yii\web\UploadedFile;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\avatar\forms
 */
class AvatarForm extends DynamicModel
{
    /**
     * @var array
     */
    public $sexOptions;
    /**
     * @var array
     */
    public $attributeMap;
    /**
     * @var array
     */
    public $labels;
    /**
     * @var array
     */
    public $config;

    /**
     * @return AvatarForm
     */
    public static function create()
    {
        $fields = [];
        $labels = [];
        $attributeMap = [];
        $sexOptions = (new Profile())->getSexOptions();
        foreach ($sexOptions as $gender => $title) {
            $attribute = 'sex' . $gender;
            $fields[] = $attribute;
            $labels[$attribute] = $title;
            $attributeMap[$attribute] = $gender;
        }

        $form = new self($fields);
        $form->addRule($fields, 'file', [
            'extensions' => 'png, jpg, gif',
        ]);
        $form->labels = $labels;
        $form->sexOptions = $sexOptions;
        $form->attributeMap = $attributeMap;

        return $form;
    }

    /**
     * @return array
     */
    public function attributeLabels()
    {
        return $this->labels;
    }

    public function getFileInstances()
    {
        foreach ($this->attributes as $attribute => $value) {
            $this->$attribute = UploadedFile::getInstance($this, $attribute);
        }
    }

    public function saveFiles()
    {
        foreach ($this->attributes as $attribute => $value) {
            $uploadedFile = $this->$attribute;
            $sex = $this->attributeMap[$attribute];
            if ($uploadedFile instanceof UploadedFile) {
                $fileName = $attribute . '.' .$uploadedFile->extension;
                $uploadedFile->saveAs(Yii::getAlias('@content/params/' . $fileName));
                $this->config[$sex] = '@web/content/params/' . $fileName;
            }
        }
    }
}
