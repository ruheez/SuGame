<?php

use app\helpers\Html;
use app\helpers\Url;
use yii\bootstrap\ActiveForm;
use yii\bootstrap\Button;

/* @var $this \yii\web\View */
/* @var $avatarForm \plugins\avatar\forms\AvatarForm */
/* @var $config array */

$this->title = Yii::t('app', 'Default avatar');
$this->params['breadcrumbs'][] = $this->title;
$this->beginContent('@app/modules/admin/views/layouts/main.php');
?>

<?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]) ?>

<?= \app\helpers\Html::errorSummary($avatarForm) ?>
<div class="row">
    <?php foreach ($avatarForm->getAttributes() as $attribute => $value): ?>
        <div class="col-xs-12 col-sm-4 col-lg-3">
            <div class="box box-widget widget-user">
                <div class="widget-user-header bg-aqua-active">
                    <h4 style="margin-top: 0; margin-bottom: 0;"><?= Html::encode($avatarForm->getAttributeLabel($attribute)) ?></h4>
                </div>
                <div class="widget-user-image" style="top: 45px">
                    <?php if (isset($config[$avatarForm->attributeMap[$attribute]])): ?>
                        <?= Html::img(Url::to($config[$avatarForm->attributeMap[$attribute]]), ['class' => 'img-circle']) ?>
                    <?php endif; ?>
                </div>
                <div class="box-footer">
                    <?= $form->field($avatarForm, $attribute)->fileInput()->label(false) ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?= Button::widget([
    'label' => Yii::t('app', 'Save'),
    'options' => ['class' => 'btn-primary']
]) ?>

<?php $form->end() ?>
