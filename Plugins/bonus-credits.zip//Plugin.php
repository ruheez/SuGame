<?php

namespace plugins\bonusCredits;

use app\controllers\SecurityController;
use app\events\FormEvent;
use app\forms\LoginForm;
use app\jobs\SendNotification;
use app\models\Photo;
use app\models\User;
use app\models\UserFinder;
use app\payments\AdminBonusTransaction;
use app\settings\HasSettings;
use app\settings\UserSettings;
use Yii;
use yii\base\Event;
use yii\base\BootstrapInterface;
use yii\db\AfterSaveEvent;
use yii\web\IdentityInterface;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\bonusCredits
 */
class Plugin extends \app\plugins\Plugin implements BootstrapInterface, HasSettings
{
    const SETTINGS_BONUS_ON_SIGNUP = 'bonusOnSignup';
    const SETTINGS_BONUS_ON_LOGIN = 'bonusOnLogin';
    const SETTINGS_BONUS_LOGIN_DELAY = 'bonusLoginDelay';
    const SETTINGS_BONUS_PER_PHOTO = 'bonusPerPhoto';
    const SETTINGS_BONUS_PER_PHOTO_MAX_PHOTOS = 'bonusPerPhotoMaxPhotos';

    /**
     * @var int
     */
    public $defaultAmount = 10;
    /**
     * @var int
     */
    public $defaultLoginDelay = 24; // hours
    /**
     * @var int
     */
    private $defaultMaxPhotos = 5;

    /**
     * @param \yii\base\Application $app
     */
    public function bootstrap($app)
    {
        if ($app instanceof \yii\web\Application) {
            $this->setupWebEvents($app);
        }
        if ($app instanceof \yii\console\Application) {
            $this->setupConsoleEvents($app);
        }

        Yii::$app->notificationManager->notificationClasses[] = BonusCreditsNotification::class;
    }

    /**
     * @param \yii\web\Application $app
     */
    public function setupWebEvents($app)
    {
        // on user sign up/connect
        Event::on(User::class, User::EVENT_AFTER_INSERT, [$this, 'afterUserCreate']);

        // on log in
        Event::on(SecurityController::class, SecurityController::EVENT_BEFORE_LOGIN, [$this, 'beforeLogin']);
        Event::on(SecurityController::class, SecurityController::EVENT_AFTER_LOGIN, [$this, 'afterLogin']);

        // on photo upload
        Event::on(Photo::class, Photo::EVENT_AFTER_INSERT, [$this, 'onPhotoUpload']);
    }

    /**
     * @param \yii\console\Application $app
     */
    public function setupConsoleEvents($app)
    {
        // cron daily/weekly
    }

    /**
     * @param AfterSaveEvent $event
     * @throws \Exception
     */
    public function afterUserCreate($event)
    {
        /** @var User $user */
        $user = $event->sender;
        $this->addCredits($user, $this->getAmountFor(self::SETTINGS_BONUS_ON_SIGNUP));
    }

    /**
     * @param FormEvent $event
     * @throws \Exception
     */
    public function beforeLogin($event)
    {
        /** @var LoginForm $form */
        $form = $event->getForm();
        $form->load(Yii::$app->request->post());
        /** @var UserFinder $finder */
        $finder = Yii::createObject(UserFinder::class);
        /** @var User $user */
        $user = $finder->findUserByUsernameOrEmail($form->login);
        if ($user !== null) {
            Yii::$app->session['lastLoginAt'] = $user->last_login_at;
        } else {
            Yii::$app->session['lastLoginAt'] = null;
        }
    }

    /**
     * @param FormEvent $event
     * @throws \Exception
     */
    public function afterLogin($event)
    {
        /** @var LoginForm $form */
        $form = $event->getForm();

        $lastLoginAt = Yii::$app->session['lastLoginAt'];
        if ($lastLoginAt !== null && !Yii::$app->user->isGuest) {
            /** @var User $user */
            $user = Yii::$app->user->identity;
            $delay = $this->getSetting(self::SETTINGS_BONUS_LOGIN_DELAY, 24);
            $delayInSecs = $delay * 3600;
            if ((time() - $lastLoginAt) > $delayInSecs) {
                $this->addCredits($user, $this->getAmountFor(self::SETTINGS_BONUS_ON_LOGIN),
                    Yii::t('youdate', 'Bonus credits for login')
                );
            }
        }
    }

    /**
     * @param AfterSaveEvent $event
     * @throws \Exception
     */
    public function onPhotoUpload($event)
    {
        /** @var Photo $photo */
        $photo = $event->sender;
        $user = $photo->user;
        $userSettings = UserSettings::forUser($user->id);

        $maxPhotos = $this->getSetting(self::SETTINGS_BONUS_PER_PHOTO_MAX_PHOTOS, $this->defaultMaxPhotos);
        $currentPhotoBonuses = $userSettings->getUserSetting(self::SETTINGS_BONUS_PER_PHOTO, 0);

        if ($currentPhotoBonuses < $maxPhotos) {
            $userSettings->setUserSetting(self::SETTINGS_BONUS_PER_PHOTO, $currentPhotoBonuses + 1);
            $this->addCredits($user, $this->getAmountFor(self::SETTINGS_BONUS_PER_PHOTO),
                Yii::t('youdate', 'Bonus credits for uploading photos')
            );
        }
    }

    /**
     * @param User|IdentityInterface $user
     * @param $amount
     * @param null $message
     * @throws \Exception
     */
    public function addCredits($user, $amount, $message = null)
    {
        if (!$user instanceof User) {
            return;
        }

        $user->refresh();

        $originalMessage = $message;
        if ($message === null) {
            $message = Yii::t('youdate', 'Credits given by administration');
        }

        Yii::$app->balanceManager->increase(['user_id' => $user->id], $amount, [
            'class' => AdminBonusTransaction::class,
            'notes' => $message,
        ]);

        if ($originalMessage === false) {
            return;
        }

        $notification = BonusCreditsNotification::instance()->from($user)
            ->source([
                'user' => $user,
                'amount' => $amount,
                'message' => $message,
            ]);
        $notification->saveRecord($user);

        Yii::$app->queue->push(Yii::createObject(SendNotification::class, [
            'notification' => $notification,
            'receiverId' => $user->id,
        ]));
    }

    /**
     * @param $key
     * @return mixed
     * @throws \Exception
     */
    public function getAmountFor($key)
    {
        return $this->getSetting($key, $this->defaultAmount);
    }

    /**
     * @return array
     */
    public function getSettings()
    {
        return [
            [
                'alias' => self::SETTINGS_BONUS_ON_SIGNUP,
                'type' => 'text',
                'label' => Yii::t('youdate', 'Bonus credits on sign up'),
                'rules' => [
                    ['default', 'value' => $this->defaultAmount],
                    ['integer', 'min' => 1, 'max' => 100000],
                ]
            ],
            [
                'alias' => self::SETTINGS_BONUS_ON_LOGIN,
                'type' => 'text',
                'label' => Yii::t('youdate', 'Bonus credits on login (return)'),
                'rules' => [
                    ['default', 'value' => $this->defaultAmount],
                    ['integer', 'min' => 1, 'max' => 100000],
                ]
            ],
            [
                'alias' => self::SETTINGS_BONUS_LOGIN_DELAY,
                'type' => 'text',
                'label' => Yii::t('youdate', 'Delay between login (return) in hours'),
                'rules' => [
                    ['default', 'value' => $this->defaultLoginDelay],
                    ['integer', 'min' => 1, 'max' => 100000],
                ]
            ],
            [
                'alias' => self::SETTINGS_BONUS_PER_PHOTO,
                'type' => 'text',
                'label' => Yii::t('youdate', 'Bonus credits per photo upload'),
                'rules' => [
                    ['default', 'value' => $this->defaultAmount],
                    ['integer', 'min' => 1, 'max' => 100000],
                ]
            ],
            [
                'alias' => self::SETTINGS_BONUS_PER_PHOTO_MAX_PHOTOS,
                'type' => 'text',
                'label' => Yii::t('youdate', 'Maximum bonuses for uploading photos'),
                'help' => Yii::t('youdate', 'Default: up to {0} photos', $this->defaultMaxPhotos),
                'rules' => [
                    ['default', 'value' => $this->defaultMaxPhotos],
                    ['integer', 'min' => 1, 'max' => 100000],
                ]
            ],
        ];
    }
}
