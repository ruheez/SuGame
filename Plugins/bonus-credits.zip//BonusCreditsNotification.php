<?php

namespace plugins\bonusCredits;

use app\helpers\Html;
use app\helpers\Url;
use app\notifications\BaseNotification;
use Yii;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package app\notifications
 */
class BonusCreditsNotification extends BaseNotification
{
    const SETTINGS_EMAIL_KEY = 'receiveEmailOnBonusCredits';

    /**
     * @var int
     */
    public $sortOrder = 125;

    /**
     * @return BonusCreditsCategory|null
     */
    public function category()
    {
        return new BonusCreditsCategory();
    }

    /**
     * @return string
     */
    public function getUrl()
    {
        return Url::to(['/balance/transactions']);
    }

    /**
     * @return string
     */
    public function getUserSettingsKey()
    {
        return self::SETTINGS_EMAIL_KEY;
    }

    /**
     * @return string
     */
    public function getMailSubject()
    {
        return Yii::t('youdate', 'Bonus credits received');
    }

    /**
     * @return null|string
     */
    public function render()
    {
        return $this->html();
    }

    /**
     * @return string
     */
    public function html()
    {
        return Html::a(Yii::t('youdate', 'You have received bonus credits.'), $this->getUrl());
    }
}
