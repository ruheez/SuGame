<?php

namespace plugins\bonusCredits;

use app\notifications\BaseNotificationCategory;
use Yii;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package app\notifications
 */
class BonusCreditsCategory extends BaseNotificationCategory
{
    /**
     * @var string
     */
    public $id = 'bonusCredits';

    /**
     * @return string
     */
    public function getTitle()
    {
        return Yii::t('youdate', 'Bonus credits');
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return Yii::t('youdate', 'Receive Notifications for bonus credits');
    }
}
