<?php

namespace plugins\cookieConsent;

use app\base\Event;
use app\modules\admin\components\Controller as AdminController;
use app\settings\HasSettings;
use plugins\cookieConsent\assets\CookieConsentAsset;
use Yii;
use yii\base\BootstrapInterface;
use yii\web\View;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\cookieConsent
 */
class Plugin extends \app\plugins\Plugin implements BootstrapInterface, HasSettings
{
    const SETTINGS_USE_CDN = 'useCdn';
    const SETTINGS_POSITION = 'position';
    const SETTINGS_COLOR_POPUP_BG = 'colorPopupBg';
    const SETTINGS_COLOR_POPUP_TEXT = 'colorPopupText';
    const SETTINGS_COLOR_POPUP_LINK = 'colorPopupLink';
    const SETTINGS_COLOR_BUTTON_BG = 'colorButtonBg';
    const SETTINGS_COLOR_BUTTON_TEXT = 'colorButtonText';
    const SETTINGS_COLOR_BUTTON_BORDER = 'colorButtonBorder';
    const SETTINGS_MESSAGE = 'message';
    const SETTINGS_DISMISS = 'dismiss';
    const SETTINGS_LINK = 'link';
    const SETTINGS_POLICY_URL = 'href';

    /**
     * @param \yii\base\Application $app
     * @return bool
     */
    public function bootstrap($app)
    {
        if (Yii::$app instanceof \yii\web\Application) {
            $this->setupWebApp($app);
        }

        return true;
    }

    /**
     * @param $app
     * @return bool
     */
    public function setupWebApp($app)
    {
        Event::on(View::class, View::EVENT_BEFORE_RENDER, [$this, 'onBeforeRender']);

        return true;
    }

    /**
     * @param $event
     * @return bool
     * @throws \yii\base\InvalidConfigException
     */
    public function onBeforeRender($event)
    {
        if (Yii::$app->controller instanceof AdminController) {
            return false;
        }

        $useCdn = $this->getSetting(self::SETTINGS_USE_CDN);
        if ($useCdn == true) {
            Yii::$container->set(CookieConsentAsset::class, ['useCdn' => true]);
        }

        /** @var View $view */
        $view = $event->sender;
        $view->registerAssetBundle(CookieConsentAsset::class, View::POS_END);
        $clientSettings = $this->getClientSettings();
        $jsonClientSettings = empty($clientSettings) ? '' : json_encode($clientSettings);
        $view->registerJs(sprintf('window.cookieconsent.initialise(%s)', $jsonClientSettings), View::POS_END);

        return true;
    }

    /**
     * @return array
     * @throws \Exception
     */
    public function getClientSettings()
    {
        $config = [
            'palette' => [
                'popup' => [
                    'background' => $this->getSetting(self::SETTINGS_COLOR_POPUP_BG, '#445'),
                    'text' => $this->getSetting(self::SETTINGS_COLOR_POPUP_TEXT, '#fff'),
                    'link' => $this->getSetting(self::SETTINGS_COLOR_POPUP_LINK, '#467fcf'),
                ],
                'button' => [
                    'background' => $this->getSetting(self::SETTINGS_COLOR_BUTTON_BG, '#467fcf'),
                    'text' => $this->getSetting(self::SETTINGS_COLOR_BUTTON_TEXT, '#fff'),
                    'border' => $this->getSetting(self::SETTINGS_COLOR_BUTTON_BORDER, '#467fcf'),
                ],
            ],
            'position' => $this->getSetting(self::SETTINGS_POSITION, 'bottom'),
        ];

        foreach ([self::SETTINGS_POLICY_URL, self::SETTINGS_MESSAGE, self::SETTINGS_DISMISS, self::SETTINGS_LINK] as $key) {
            $value = $this->getSetting($key);
            if (!empty($value)) {
                $config['content'][$key] = $value;
            }
        }

        return $config;
    }

    /**
     * @return array
     */
    public function getSettings()
    {
        return [
            [
                'alias' => self::SETTINGS_USE_CDN,
                'type' => 'checkbox',
                'label' => Yii::t('app', 'Use CDN instead of local files'),
                'rules' => [
                    ['default', 'value' => false],
                    ['boolean'],
                ]
            ],
            [
                'alias' => self::SETTINGS_POSITION,
                'type' => 'dropdown',
                'label' => Yii::t('app', 'Position'),
                'options' => [
                    'top' => Yii::t('app', 'Top'),
                    'bottom' => Yii::t('app', 'Bottom'),
                    'bottom-left' => Yii::t('app', 'Bottom-Left'),
                    'bottom-right' => Yii::t('app', 'Bottom-Right'),
                ],
                'rules' => [
                    ['default', 'value' => 'bottom'],
                    ['in', 'range' => ['top', 'bottom', 'bottom-left', 'bottom-right']],
                ]
            ],
            // content
            [
                'alias' => self::SETTINGS_MESSAGE,
                'type' => 'text',
                'label' => Yii::t('app', 'Message'),
                'rules' => [
                    ['string', 'max' => 255],
                ]
            ],
            [
                'alias' => self::SETTINGS_LINK,
                'type' => 'text',
                'label' => Yii::t('app', 'Link text'),
                'rules' => [
                    ['string', 'max' => 255],
                ]
            ],
            [
                'alias' => self::SETTINGS_DISMISS,
                'type' => 'text',
                'label' => Yii::t('app', 'Button text'),
                'rules' => [
                    ['string', 'max' => 255],
                ]
            ],
            [
                'alias' => self::SETTINGS_POLICY_URL,
                'type' => 'text',
                'label' => Yii::t('app', 'Policy URL'),
                'rules' => [
                    ['string', 'max' => 255],
                ]
            ],
            // popup
            [
                'alias' => self::SETTINGS_COLOR_POPUP_BG,
                'type' => 'color',
                'label' => Yii::t('app', 'Popup background color'),
                'rules' => [
                    ['default', 'value' => '#445'],
                    ['string', 'min' => '3', 'max' => 32],
                ]
            ],
            [
                'alias' => self::SETTINGS_COLOR_POPUP_TEXT,
                'type' => 'color',
                'label' => Yii::t('app', 'Popup text color'),
                'rules' => [
                    ['default', 'value' => '#fff'],
                    ['string', 'min' => '3', 'max' => 32],
                ]
            ],
            [
                'alias' => self::SETTINGS_COLOR_POPUP_LINK,
                'type' => 'color',
                'label' => Yii::t('app', 'Popup link color'),
                'rules' => [
                    ['default', 'value' => '#467fcf'],
                    ['string', 'min' => '3', 'max' => 32],
                ]
            ],
            // button
            [
                'alias' => self::SETTINGS_COLOR_BUTTON_BG,
                'type' => 'color',
                'label' => Yii::t('app', 'Button background color'),
                'rules' => [
                    ['default', 'value' => '#467fcf'],
                    ['string', 'min' => '3', 'max' => 32],
                ]
            ],
            [
                'alias' => self::SETTINGS_COLOR_BUTTON_TEXT,
                'type' => 'color',
                'label' => Yii::t('app', 'Button text color'),
                'rules' => [
                    ['default', 'value' => '#fff'],
                    ['string', 'min' => '3', 'max' => 32],
                ]
            ],
            [
                'alias' => self::SETTINGS_COLOR_BUTTON_BORDER,
                'type' => 'color',
                'label' => Yii::t('app', 'Button border color'),
                'rules' => [
                    ['default', 'value' => '#467fcf'],
                    ['string', 'min' => '3', 'max' => 32],
                ]
            ],
        ];
    }
}
