<?php

namespace plugins\cookieConsent\assets;

use yii\web\AssetBundle;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package plugins\cookieConsent\assets
 */
class CookieConsentAsset extends AssetBundle
{
    /**
     * @var string
     */
    public $baseUrl = '@web/content/plugins/cookie-consent/static';
    /**
     * @var bool
     */
    public $useCdn = false;
    /**
     * @var string
     */
    public $cdnJs = 'https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.js';
    /**
     * @var string
     */
    public $cdnCss = 'https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css';

    public function init()
    {
        parent::init();
        if ($this->useCdn == true) {
            $this->js[] = $this->cdnJs;
            $this->css[] = $this->cdnCss;
        } else {
            $this->js[] = 'js/cookieconsent.min.js';
            $this->css[] = 'css/cookieconsent.min.css';
        }
    }
}
